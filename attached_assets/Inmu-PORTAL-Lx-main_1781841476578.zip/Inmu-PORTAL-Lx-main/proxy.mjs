import http from 'http';

const TARGET_PORT = 26083;
const LISTEN_PORT = 5000;

http.createServer((req, res) => {
  const options = {
    hostname: 'localhost',
    port: TARGET_PORT,
    path: req.url,
    method: req.method,
    headers: { ...req.headers, host: `localhost:${TARGET_PORT}` },
  };
  const proxy = http.request(options, (proxyRes) => {
    res.writeHead(proxyRes.statusCode, proxyRes.headers);
    proxyRes.pipe(res, { end: true });
  });
  proxy.on('error', (e) => {
    res.writeHead(502);
    res.end('Bad Gateway: ' + e.message);
  });
  req.pipe(proxy, { end: true });
}).listen(LISTEN_PORT, '0.0.0.0', () => {
  console.log(`Proxy listening on port ${LISTEN_PORT} → ${TARGET_PORT}`);
});
